# SVGA-Samples

以下动画版权归 YY Inc. 所有，仅用于学习使用，禁止商业使用。

* angel.svga
* halloween.svga
* kingset.svga
* posche.svga
* rose.svga
