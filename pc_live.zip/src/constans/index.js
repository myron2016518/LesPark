import CONSTANTS from './constants';
import APIS from './apis';
import AllUrl from './url';

export default {
    CONSTANTS,
    APIS,
    AllUrl
}