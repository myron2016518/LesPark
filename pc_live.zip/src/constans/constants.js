let constants = {
	// 主机域名
	url: {
		dev: 'https://api.lespark.cn', // 本地私有开发环境
	},
}

export default constants
