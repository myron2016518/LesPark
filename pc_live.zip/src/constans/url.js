let AllUrl = {
  url: {
    // dev: 'http://www.lespark.cn',
    // dev: 'http://47.93.50.5:10084'
    // dev: "http://test.lespark.cn",
    dev: "http://localhost:8181/api",
    dev2: "http://localhost:8181/testlala",
  },
  appid: {
    wx: "wxb8745f4b45b0c5fd",
    qq: "101510896",
    xinlang: "2829403593",
    facebook: "1397507653823766",
    ins: "d539702e66884929810e3ccd0ff4d059",
    line: "1514382018",
  },
  redirect_uri: {
    wx_url: "http://www.lespark.cn/pc_login_callback/wx",
    qq_url: "http://www.lespark.cn/pc_login_callback/qq",
    xinlang_url: "http://www.lespark.cn/pc_login_callback/sina",
    facebook_url: "http://www.lespark.cn/pc_login_callback/facebook",
    ins_url: "http://www.lespark.cn/pc_login_callback/instagram",
    line_url: "http://www.lespark.cn/pc_login_callback/line",
  },
};

export default AllUrl;